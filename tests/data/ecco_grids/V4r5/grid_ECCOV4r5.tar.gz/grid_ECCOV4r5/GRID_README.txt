cp -r /nobackupp11/owang/ECCO/llc90/V4r5/grid .
